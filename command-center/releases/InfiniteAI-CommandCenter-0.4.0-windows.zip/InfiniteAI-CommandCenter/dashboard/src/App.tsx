import { createContext, useCallback, useContext, useEffect, useRef, useState } from "react";
import { BrowserRouter, Link, Navigate, Route, Routes, useLocation } from "react-router-dom";
import { api, ApiError, type SystemStatus, type User } from "./api";
import { usePoll } from "./hooks";
import { Icon } from "./icons";
import Activity from "./pages/Activity";
import Agents from "./pages/Agents";
import AutomationLogs from "./pages/AutomationLogs";
import Approvals from "./pages/Approvals";
import CreditRepair from "./pages/CreditRepair";
import Dashboard from "./pages/Dashboard";
import Drafts from "./pages/Drafts";
import Email from "./pages/Email";
import Integrations from "./pages/Integrations";
import KnowledgeBase from "./pages/KnowledgeBase";
import Leads from "./pages/Leads";
import Login from "./pages/Login";
import Outbox from "./pages/Outbox";
import Schedules from "./pages/Schedules";
import SeoMarketing from "./pages/SeoMarketing";
import Servers from "./pages/Servers";
import Settings from "./pages/Settings";
import Social from "./pages/Social";
import Supervisor from "./pages/Supervisor";
import Support from "./pages/Support";
import Tasks from "./pages/Tasks";
import Websites from "./pages/Websites";
import Workflows from "./pages/Workflows";
import CommandBar from "./shell/CommandBar";
import { AccountMenu, NotificationsMenu } from "./shell/Menus";
import { APP_TITLE, pageTitle } from "./shell/nav";
import Sidebar, { MenuButton } from "./shell/Sidebar";

interface AuthState {
  user: User;
  canOperate: boolean;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthState | null>(null);

export function useAuth(): AuthState {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth outside AuthContext");
  return ctx;
}

function Shell({ user, onSignOut }: { user: User; onSignOut: () => Promise<void> }) {
  const status = usePoll(() => api.get<SystemStatus>("/api/system/status"), 10_000);
  const canOperate = user.role === "admin" || user.role === "operator";
  const [menuOpen, setMenuOpen] = useState(false);
  const menuButton = useRef<HTMLButtonElement>(null);
  const header = useRef<HTMLElement>(null);
  const main = useRef<HTMLElement>(null);
  const restoreFocus = useRef(false);
  const { pathname } = useLocation();
  const s = status.data;

  useEffect(() => {
    document.title = pageTitle(pathname);
  }, [pathname]);

  const closeMenu = useCallback(() => {
    restoreFocus.current = true;
    setMenuOpen(false);
  }, []);

  // Phone drawer: while it is open the rest of the page is inert; Escape closes it and the focus goes back to the menu button.
  useEffect(() => {
    for (const el of [header.current, main.current]) if (el) el.inert = menuOpen;
    if (!menuOpen) {
      if (restoreFocus.current) menuButton.current?.focus();
      restoreFocus.current = false;
      return;
    }
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && closeMenu();
    // The drawer only exists on a phone-width screen; widening the window closes it.
    const wide = window.matchMedia?.("(min-width: 761px)");
    const onWide = () => wide?.matches && setMenuOpen(false);
    document.addEventListener("keydown", onKey);
    wide?.addEventListener("change", onWide);
    return () => {
      document.removeEventListener("keydown", onKey);
      wide?.removeEventListener("change", onWide);
    };
  }, [menuOpen, closeMenu]);

  return (
    <AuthContext.Provider value={{ user, canOperate, signOut: onSignOut }}>
      <a className="skip-link" href="#main">
        Skip to content
      </a>
      <div className={`layout ${menuOpen ? "menu-open" : ""}`}>
        <header className="topbar" ref={header}>
          <MenuButton ref={menuButton} open={menuOpen} onClick={() => setMenuOpen((o) => !o)} />
          <Link to="/" className="brand" aria-label="Infinite AI Command Center, dashboard">
            <span className="logo" aria-hidden>
              ∞
            </span>
            <span className="brand-text">
              <span className="brand-name">Infinite AI</span>
              <span className="brand-sub">Command Center</span>
            </span>
          </Link>
          <CommandBar />
          <div className="top-actions">
            <NotificationsMenu status={s} />
            {user.role === "admin" ? (
              <Link className="top-btn" to="/settings" aria-label="Settings" title="Settings">
                <Icon name="settings" />
              </Link>
            ) : null}
            <AccountMenu />
          </div>
        </header>
        <Sidebar user={user} status={s} open={menuOpen} onNavigate={() => setMenuOpen(false)} onClose={closeMenu} />
        {menuOpen ? <div className="scrim" onClick={closeMenu} aria-hidden /> : null}
        <main className="content" id="main" tabIndex={-1} ref={main}>
          <Routes>
            <Route path="/" element={<Dashboard status={s} />} />
            <Route path="/agents" element={<Agents />} />
            <Route path="/workflows" element={<Workflows />} />
            <Route path="/websites" element={<Websites />} />
            <Route path="/seo" element={<SeoMarketing />} />
            <Route path="/servers" element={<Servers />} />
            <Route path="/email" element={<Email />} />
            <Route path="/credit-repair" element={<CreditRepair />} />
            <Route path="/social" element={<Social />} />
            <Route path="/logs" element={<AutomationLogs />} />
            <Route path="/kb" element={<KnowledgeBase />} />
            <Route path="/settings" element={<Settings />} />
            <Route path="/approvals" element={<Approvals />} />
            <Route path="/tasks" element={<Tasks />} />
            <Route path="/supervisor" element={<Supervisor />} />
            <Route path="/leads" element={<Leads />} />
            <Route path="/support" element={<Support />} />
            <Route path="/drafts" element={<Drafts />} />
            <Route path="/outbox" element={<Outbox />} />
            <Route path="/schedules" element={<Schedules />} />
            <Route path="/integrations" element={<Integrations />} />
            <Route path="/activity" element={<Activity />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </main>
      </div>
    </AuthContext.Provider>
  );
}

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [checked, setChecked] = useState(false);

  const loadMe = useCallback(async () => {
    try {
      const me = await api.get<{ user: User }>("/api/auth/me");
      setUser(me.user);
    } catch (e) {
      if (!(e instanceof ApiError && e.status === 401)) console.error(e);
      setUser(null);
    } finally {
      setChecked(true);
    }
  }, []);

  useEffect(() => {
    void loadMe();
    const onUnauthorized = () => setUser(null);
    window.addEventListener("cc:unauthorized", onUnauthorized);
    return () => window.removeEventListener("cc:unauthorized", onUnauthorized);
  }, [loadMe]);

  useEffect(() => {
    if (checked && !user) document.title = `Sign in · ${APP_TITLE}`;
  }, [checked, user]);

  const signOut = useCallback(async () => {
    await api.post("/api/auth/logout").catch(() => undefined);
    setUser(null);
  }, []);

  if (!checked) return <div className="boot">Loading…</div>;
  return (
    <BrowserRouter>
      {user ? <Shell user={user} onSignOut={signOut} /> : <Login onSignedIn={setUser} />}
    </BrowserRouter>
  );
}
